import pytest
from src.application.use_cases.process_query import process_query
from src.infrastructure.service_clients.chatgpt_client import ChatGPTClient

@pytest.mark.asyncio
async def test_process_query_with_mocked_client(mocker):
    mock_client = mocker.patch.object(ChatGPTClient, "send_query", return_value="Mocked response")
    response = await process_query("chatgpt", "Test prompt")
    assert response == "Mocked response"