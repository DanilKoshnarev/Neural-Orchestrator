from fastapi.testclient import TestClient
from src.app.main import app

client = TestClient(app)

def test_process_query():
    response = client.post("/query", json={"prompt": "Hello", "service": "chatgpt"})
    assert response.status_code == 200
    assert "response" in response.json()