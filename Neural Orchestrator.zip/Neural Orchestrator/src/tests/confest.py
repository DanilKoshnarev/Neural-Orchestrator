import pytest
from src.infrastructure.redis_cache import RedisCache

@pytest.fixture(scope="session", autouse=True)
async def setup_redis():
    await RedisCache.init_connection(host="localhost", port=6379)
    yield
    await RedisCache.close_connection()