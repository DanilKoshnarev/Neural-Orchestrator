from pydantic import BaseModel
from datetime import datetime

class Response(BaseModel):
    service: str
    response: str
    timestamp: datetime