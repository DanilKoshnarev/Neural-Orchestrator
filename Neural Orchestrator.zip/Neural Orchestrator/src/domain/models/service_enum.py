from enum import Enum

class ServiceEnum(str, Enum):
    CHATGPT = "chatgpt"
    GEMINI = "gemini"
    HOPPICOPY = "hoppicopy"
    BING_AI = "bing_ai"
    CLAUDE = "claude"
    PERPLEXITY = "perplexity"
    YOUCHAT = "youchat"
    DEEPL = "deepl"
    JASPER = "jasper"
    COPYAI = "copyai"