from typing import Protocol

class ServiceProtocol(Protocol):
    async def send_query(self, prompt: str) -> str:
        """Отправка запроса к сервису"""
        ...