import aioredis

class RedisCache:
    _redis = None

    @classmethod
    async def init_connection(cls, host: str, port: int):
        cls._redis = await aioredis.from_url(f"redis://{host}:{port}")

    @classmethod
    async def close_connection(cls):
        if cls._redis:
            await cls._redis.close()

    @classmethod
    async def get(cls, key: str) -> str:
        return await cls._redis.get(key, encoding="utf-8")

    @classmethod
    async def set(cls, key: str, value: str, expire: int = 3600):
        await cls._redis.set(key, value, ex=expire)