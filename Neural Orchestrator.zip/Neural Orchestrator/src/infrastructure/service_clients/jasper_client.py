from src.domain.protocols.service_protocol import ServiceProtocol

class JasperClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к Jasper AI
        return "Ответ от Jasper"