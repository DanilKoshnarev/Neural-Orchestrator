from src.domain.models.service_enum import ServiceEnum
from src.infrastructure.service_clients.chatgpt_client import ChatGPTClient
from src.infrastructure.service_clients.gemini_client import GeminiClient
# Импорт остальных клиентов

def get_client(service: str):
    if service == ServiceEnum.CHATGPT:
        return ChatGPTClient()
    elif service == ServiceEnum.GEMINI:
        return GeminiClient()
    # Добавить другие сервисы
    else:
        raise ValueError(f"Unknown service: {service}")