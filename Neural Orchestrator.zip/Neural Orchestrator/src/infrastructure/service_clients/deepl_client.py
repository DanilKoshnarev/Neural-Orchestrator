from src.domain.protocols.service_protocol import ServiceProtocol

class DeepLClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к DeepL
        return "Ответ от DeepL"