from src.domain.protocols.service_protocol import ServiceProtocol

class BingAIClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к Bing AI
        return "Ответ от Bing AI"