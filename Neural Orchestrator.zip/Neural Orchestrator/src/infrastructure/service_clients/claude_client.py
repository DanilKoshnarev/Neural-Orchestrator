from src.domain.protocols.service_protocol import ServiceProtocol

class ClaudeClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к Claude AI
        return "Ответ от Claude"