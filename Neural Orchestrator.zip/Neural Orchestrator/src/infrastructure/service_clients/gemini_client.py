from src.domain.protocols.service_protocol import ServiceProtocol

class GeminiClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к Gemini AI
        return "Ответ от Gemini"