from src.domain.protocols.service_protocol import ServiceProtocol

class YouChatClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к YouChat AI
        return "Ответ от YouChat"