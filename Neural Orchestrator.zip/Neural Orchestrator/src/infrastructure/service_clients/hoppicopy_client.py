from src.domain.protocols.service_protocol import ServiceProtocol

class HoppicopyClient(ServiceProtocol):
    async def send_query(self, prompt: str) -> str:
        # Код для отправки запроса к Hoppicopy AI
        return "Ответ от Hoppicopy"