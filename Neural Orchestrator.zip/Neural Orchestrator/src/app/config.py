from pydantic import BaseSettings
#пайдентииик!
class Settings(BaseSettings):
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    API_TIMEOUT: int = 10  # Таймаут для запросов
    MAX_PROMPT_LENGTH: int = 500  # Максимальная длина текста запроса

settings = Settings()