from fastapi import FastAPI
from src.app.config import settings
from src.interfaces.api.router import router
from src.infrastructure.redis_cache import RedisCache

# Инициализацируем FastAPI
app = FastAPI(
    title="Neural Orchestrator",
    description="Менеджер взаимодействия с различными нейросетями",
    version="1.0.0"
)

# Подключаем маршруты
app.include_router(router)

# Инициализируем Redis
@app.on_event("startup")
async def startup_event():
    await RedisCache.init_connection(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT
    )

@app.on_event("shutdown")
async def shutdown_event():
    await RedisCache.close_connection()