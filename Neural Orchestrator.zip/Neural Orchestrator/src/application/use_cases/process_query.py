from src.infrastructure.redis_cache import RedisCache
from src.infrastructure.service_clients import get_client

async def process_query(service: str, prompt: str) -> str:
    # Проверяем кеш
    cached_response = await RedisCache.get(f"{service}:{prompt}")
    if cached_response:
        return cached_response

    # Получаем клиента сервиса
    client = get_client(service)
    response = await client.send_query(prompt)

    # Сохраняем в кеш
    await RedisCache.set(f"{service}:{prompt}", response)

    return response