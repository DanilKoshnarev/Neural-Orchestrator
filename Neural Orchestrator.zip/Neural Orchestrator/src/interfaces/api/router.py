from fastapi import APIRouter, HTTPException
from src.domain.models.query import Query
from src.application.use_cases.process_query import process_query

router = APIRouter()

@router.post("/query/")
async def query_endpoint(query: Query):
    try:
        response = await process_query(query.service, query.prompt)
        return {"service": query.service, "response": response}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))